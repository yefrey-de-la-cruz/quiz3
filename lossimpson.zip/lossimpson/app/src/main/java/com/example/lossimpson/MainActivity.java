package com.example.lossimpson;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerPersonajes;
    Button btnAnterior, btnSiguiente;
    TextView txtPagina;

    ArrayList<Personaje> listaPersonajes;
    PersonajeAdapter adapter;

    RequestQueue requestQueue;

    int paginaActual = 1;
    int totalPaginas = 1;

    String URL_BASE = "https://thesimpsonsapi.com/api/characters";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerPersonajes = findViewById(R.id.imgPersonaje);
        btnAnterior = findViewById(R.id.txtEdad);
        btnSiguiente = findViewById(R.id.txtGenero);
        txtPagina = findViewById(R.id.txtNombre);


        listaPersonajes = new ArrayList<>();

        recyclerPersonajes.setLayoutManager(
                new GridLayoutManager(this, 2)
        );

        adapter = new PersonajeAdapter(listaPersonajes);
        recyclerPersonajes.setAdapter(adapter);

        requestQueue = Volley.newRequestQueue(this);

        cargarPersonajes(paginaActual);

        btnAnterior.setOnClickListener(v -> {
            if (paginaActual > 1) {
                paginaActual--;
                cargarPersonajes(paginaActual);
            }
        });

        btnSiguiente.setOnClickListener(v -> {
            if (paginaActual < totalPaginas) {
                paginaActual++;
                cargarPersonajes(paginaActual);
            }
        });
    }

    private void cargarPersonajes(int pagina) {

        String url = URL_BASE + "?page=" + pagina;

        StringRequest solicitud = new StringRequest(
                Request.Method.GET,
                url,
                respuesta -> {
                    try {
                        JSONObject objeto = new JSONObject(respuesta);

                        JSONArray resultados = objeto.getJSONArray("results");

                        totalPaginas = objeto.getInt("pages");

                        listaPersonajes.clear();

                        for (int i = 0; i < resultados.length(); i++) {

                            JSONObject personajeJSON = resultados.getJSONObject(i);

                            int id = personajeJSON.optInt("id", 0);

                            String nombre = personajeJSON.optString(
                                    "name", "Sin nombre");

                            String ocupacion = personajeJSON.optString(
                                    "occupation", "No disponible");

                            String edad = personajeJSON.isNull("age")
                                    ? "No disponible"
                                    : personajeJSON.optString("age");

                            String genero = personajeJSON.optString(
                                    "gender", "No disponible");

                            String rutaImagen = personajeJSON.optString(
                                    "portrait_path", "");

                            String imagen = "https://cdn.thesimpsonsapi.com/500"
                                    + rutaImagen;

                            Personaje personaje = new Personaje(
                                    id,
                                    nombre,
                                    ocupacion,
                                    edad,
                                    genero,
                                    imagen
                            );

                            listaPersonajes.add(personaje);
                        }

                        adapter.notifyDataSetChanged();

                        txtPagina.setText(
                                "Página " + paginaActual + " de " + totalPaginas
                        );

                        btnAnterior.setEnabled(paginaActual > 1);
                        btnSiguiente.setEnabled(paginaActual < totalPaginas);

                    } catch (Exception e) {
                        Toast.makeText(this,
                                "Error al procesar los personajes",
                                Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this,
                        "No se pudo conectar con la API",
                        Toast.LENGTH_SHORT).show()
        );

        requestQueue.add(solicitud);
    }
}
