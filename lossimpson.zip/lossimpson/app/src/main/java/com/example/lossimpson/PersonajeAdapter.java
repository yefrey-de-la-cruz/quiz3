
package com.example.lossimpson;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class PersonajeAdapter extends RecyclerView.Adapter<PersonajeAdapter.ViewHolder> {

    private ArrayList<Personaje> listaPersonajes;

    public PersonajeAdapter(ArrayList<Personaje> listaPersonajes) {
        this.listaPersonajes = listaPersonajes;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_personaje, parent, false);
        return new ViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Personaje personaje = listaPersonajes.get(position);

        holder.txtNombre.setText(personaje.getNombre());
        holder.txtEdad.setText("Edad: " + personaje.getEdad());
        holder.txtOcupacion.setText("Ocupación: " + personaje.getOcupacion());
        holder.txtGenero.setText("Género: " + personaje.getGenero());

        Glide.with(holder.itemView.getContext())
                .load(personaje.getImagen())
                .placeholder(android.R.drawable.ic_menu_gallery)
                .into(holder.imgPersonaje);
    }

    @Override
    public int getItemCount() {
        return listaPersonajes.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgPersonaje;
        TextView txtNombre, txtEdad, txtOcupacion, txtGenero;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgPersonaje = itemView.findViewById(R.id.imgPersonaje);
            txtNombre = itemView.findViewById(R.id.txtNombre);
            txtEdad = itemView.findViewById(R.id.txtEdad);
            txtOcupacion = itemView.findViewById(R.id.txtOcupacion);
            txtGenero = itemView.findViewById(R.id.txtGenero);
        }
    }
}
