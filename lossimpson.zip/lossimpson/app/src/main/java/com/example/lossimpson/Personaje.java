package com.example.lossimpson;



public class Personaje {

    private int id;
    private String nombre;
    private String ocupacion;
    private String edad;
    private String genero;
    private String imagen;

    public Personaje(int id, String nombre, String ocupacion,
                     String edad, String genero, String imagen) {
        this.id = id;
        this.nombre = nombre;
        this.ocupacion = ocupacion;
        this.edad = edad;
        this.genero = genero;
        this.imagen = imagen;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getOcupacion() {
        return ocupacion;
    }

    public String getEdad() {
        return edad;
    }

    public String getGenero() {
        return genero;
    }

    public String getImagen() {
        return imagen;
    }
}

